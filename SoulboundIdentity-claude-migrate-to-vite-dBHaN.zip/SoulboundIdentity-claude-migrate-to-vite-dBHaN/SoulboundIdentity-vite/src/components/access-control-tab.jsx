import React, { useState, useEffect } from 'react';
import { CONFIG } from '../contracts';
import { queryFilterInChunks, shortenAddress, formatDate } from '../utils';
import { Card, Button, Input, Modal, LoadingSpinner } from './ui';

export function AccessControlTab({ contracts, selectedToken, userTokens, showNotification }) {
    const [pendingRequests, setPendingRequests] = useState([]);
    const [grantedAccess, setGrantedAccess] = useState([]);
    const [tokensICanAccess, setTokensICanAccess] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showRequestModal, setShowRequestModal] = useState(false);
    const [requestTokenId, setRequestTokenId] = useState('');
    const [showViewModal, setShowViewModal] = useState(false);
    const [viewingToken, setViewingToken] = useState(null);
    const [loadingDetails, setLoadingDetails] = useState(false);
    const [showApproveModal, setShowApproveModal] = useState(false);
    const [approvingRequester, setApprovingRequester] = useState(null);
    const [selectedCredTypes, setSelectedCredTypes] = useState({0: true, 1: true, 2: true, 3: true, 4: true});
    const [selectedSocialSections, setSelectedSocialSections] = useState({0: true, 1: true, 2: true});
    const [selectedRequests, setSelectedRequests] = useState(new Set());
    const [showBatchApproveModal, setShowBatchApproveModal] = useState(false);

    const getExpiryCountdown = (expiresAt) => {
        const now = Math.floor(Date.now() / 1000);
        const timeLeft = expiresAt - now;
        if (timeLeft <= 0) return '⚫ Expired';
        const days = Math.floor(timeLeft / 86400);
        const hours = Math.floor((timeLeft % 86400) / 3600);
        const minutes = Math.floor((timeLeft % 3600) / 60);
        if (days > 0) return `🟢 Expires in ${days} day${days > 1 ? 's' : ''} ${hours}h`;
        if (hours > 0) return `🟡 Expires in ${hours} hour${hours > 1 ? 's' : ''} ${minutes}m`;
        return `🔴 Expires in ${minutes} minute${minutes > 1 ? 's' : ''}`;
    };

    const getAccessStatusLabel = (status) => {
        const statusMap = {
            0: { label: 'No Request', color: 'var(--text-muted)', icon: '⚪' },
            1: { label: 'Pending', color: 'var(--warning)', icon: '🟡' },
            2: { label: 'Approved', color: 'var(--success)', icon: '🟢' },
            3: { label: 'Denied', color: 'var(--error)', icon: '🔴' }
        };
        return statusMap[status] || statusMap[0];
    };

    useEffect(() => {
        if (selectedToken && contracts) loadAccessData();
        if (contracts) loadTokensICanAccess();
    }, [selectedToken, contracts]);

    const loadAccessData = async () => {
        if (!selectedToken) return;
        setLoading(true);
        try {
            let requesters = [];
            try {
                const requests = await contracts.soulbound.getPendingRequests(selectedToken, 0, 50);
                requesters = requests.requesters ?? requests[0] ?? [];
            } catch (e) {
                console.error('getPendingRequests failed:', e.reason || e.data || e.message);
            }
            const enhancedRequests = await Promise.all(
                requesters.map(async (requester) => {
                    try {
                        const status = await contracts.soulbound.getAccessStatus(selectedToken, requester);
                        return { address: requester, status };
                    } catch {
                        return { address: requester, status: 1 };
                    }
                })
            );
            setPendingRequests(enhancedRequests);
            const approvedFilter = contracts.soulbound.filters.AccessApproved(selectedToken);
            const latestBlock = await contracts.soulbound.provider.getBlockNumber();
            const fromBlock = Math.max(CONFIG.DEPLOYMENT_BLOCK, latestBlock - CONFIG.MAX_BLOCK_LOOKBACK);
            const approvedEvents = await queryFilterInChunks(contracts.soulbound, approvedFilter, fromBlock, latestBlock);
            const uniqueAddresses = [...new Set(approvedEvents.map(e => e.args.requester))];
            const accessResults = await Promise.all(
                uniqueAddresses.map(async (address) => {
                    try {
                        const [hasAccess, expiresAt] = await contracts.soulbound.checkAccess(selectedToken, address);
                        return hasAccess ? { address, expiresAt: expiresAt.toNumber() } : null;
                    } catch { return null; }
                })
            );
            setGrantedAccess(accessResults.filter(Boolean));
        } catch (error) {
            console.error('Error loading access data:', error.reason || error.data || error.message, error);
        } finally {
            setLoading(false);
        }
    };

    const loadTokensICanAccess = async () => {
        if (!contracts) return;
        try {
            const myAddress = await contracts.soulbound.signer.getAddress();
            const latestBlock = await contracts.soulbound.provider.getBlockNumber();
            const fromBlock = Math.max(CONFIG.DEPLOYMENT_BLOCK, latestBlock - CONFIG.MAX_BLOCK_LOOKBACK);
            const indexedFilter = contracts.soulbound.filters.AccessApproved(null, myAddress);
            const events = await queryFilterInChunks(contracts.soulbound, indexedFilter, fromBlock, latestBlock);
            const tokenIds = [...new Set(events.map(e => e.args.tokenId.toNumber()))];
            const results = await Promise.all(
                tokenIds.map(async (tokenId) => {
                    try {
                        const owner = await contracts.soulbound.ownerOf(tokenId);
                        if (owner.toLowerCase() === myAddress.toLowerCase()) return null;
                        const [hasAccess, expiresAt] = await contracts.soulbound.checkAccess(tokenId, myAddress);
                        if (!hasAccess) return null;
                        let metadataCID = '';
                        try { metadataCID = await contracts.soulbound.tokenURI(tokenId); } catch {}
                        return { tokenId, owner, expiresAt: expiresAt.toNumber(), cid: metadataCID || 'N/A' };
                    } catch { return null; }
                })
            );
            setTokensICanAccess(results.filter(Boolean));
        } catch (error) {
            console.error('Error loading accessible tokens:', error.reason || error.data || error.message, error);
        }
    };

    const handleRequestAccess = async () => {
        try {
            if (!requestTokenId) { showNotification('Please enter a token ID', 'warning'); return; }
            const tokenIdNumber = parseInt(requestTokenId);
            try { await contracts.soulbound.ownerOf(tokenIdNumber); } catch { showNotification('Token does not exist', 'error'); return; }
            const tx = await contracts.soulbound.requestAccess(tokenIdNumber);
            showNotification('Requesting access...', 'info');
            await tx.wait();
            showNotification('Access request sent!', 'success');
            setShowRequestModal(false);
            setRequestTokenId('');
        } catch (error) {
            console.error('❌ Error requesting access:', error);
            let errorMessage = 'Failed to request access';
            if (error.message.includes('RequestAlreadyExists')) errorMessage = 'You already have a pending request for this token';
            else if (error.message.includes('TooManyRequests')) errorMessage = 'You have reached the maximum requests per day';
            else if (error.message.includes('RequestCooldown')) errorMessage = 'Please wait before requesting access again';
            else if (error.message.includes('OnlyTokenOwner')) errorMessage = 'You cannot request access to your own token';
            else if (error.message.includes('OwnerHasAccess')) errorMessage = 'Token owner already has full access';
            else if (error.reason) errorMessage = error.reason;
            else if (error.message) errorMessage = error.message;
            showNotification(errorMessage, 'error');
        }
    };

    const openApproveModal = (requester) => {
        setApprovingRequester(requester);
        setSelectedCredTypes({0: true, 1: true, 2: true, 3: true, 4: true});
        setSelectedSocialSections({0: true, 1: true, 2: true});
        setShowApproveModal(true);
    };

    const buildBitmasks = () => {
        const credBitmask = Object.entries(selectedCredTypes).reduce((mask, [bit, checked]) => checked ? mask | (1 << parseInt(bit)) : mask, 0);
        const socialBitmask = Object.entries(selectedSocialSections).reduce((mask, [bit, checked]) => checked ? mask | (1 << parseInt(bit)) : mask, 0);
        return { credBitmask, socialBitmask };
    };

    const handleApproveAccess = async () => {
        if (!approvingRequester) return;
        try {
            const duration = 30 * 24 * 60 * 60;
            const { credBitmask, socialBitmask } = buildBitmasks();
            showNotification('Step 1/3: Approving identity access...', 'info');
            const tx1 = await contracts.soulbound.approveAccess(selectedToken, approvingRequester, duration);
            await tx1.wait();
            if (credBitmask > 0) {
                showNotification('Step 2/3: Granting credential access...', 'info');
                const tx2 = await contracts.credentials.grantCredentialAccess(selectedToken, approvingRequester, credBitmask);
                await tx2.wait();
            }
            if (socialBitmask > 0) {
                showNotification('Step 3/3: Granting social access...', 'info');
                const tx3 = await contracts.social.grantSocialAccess(selectedToken, approvingRequester, socialBitmask);
                await tx3.wait();
            }
            showNotification('Access approved with permissions!', 'success');
            setShowApproveModal(false);
            setApprovingRequester(null);
            loadAccessData();
        } catch (error) {
            console.error('Error approving access:', error);
            showNotification('Failed to approve access', 'error');
        }
    };

    const handleBatchApprove = async () => {
        if (selectedRequests.size === 0) return;
        try {
            const duration = 30 * 24 * 60 * 60;
            const requesters = Array.from(selectedRequests);
            const durations = requesters.map(() => duration);
            const { credBitmask, socialBitmask } = buildBitmasks();
            showNotification(`Step 1/3: Approving ${requesters.length} request(s)...`, 'info');
            const tx1 = await contracts.soulbound.batchApproveAccess(selectedToken, requesters, durations);
            await tx1.wait();
            if (credBitmask > 0) {
                showNotification('Step 2/3: Granting credential access...', 'info');
                const tx2 = await contracts.credentials.batchGrantCredentialAccess(selectedToken, requesters, credBitmask);
                await tx2.wait();
            }
            if (socialBitmask > 0) {
                showNotification('Step 3/3: Granting social access...', 'info');
                const tx3 = await contracts.social.batchGrantSocialAccess(selectedToken, requesters, socialBitmask);
                await tx3.wait();
            }
            showNotification(`${requesters.length} request(s) approved!`, 'success');
            setShowBatchApproveModal(false);
            setSelectedRequests(new Set());
            loadAccessData();
        } catch (error) {
            console.error('Error batch approving:', error);
            showNotification('Failed to batch approve', 'error');
        }
    };

    const handleBatchDeny = async () => {
        if (selectedRequests.size === 0) return;
        try {
            const requesters = Array.from(selectedRequests);
            showNotification(`Denying ${requesters.length} request(s)...`, 'info');
            const tx = await contracts.soulbound.batchDenyAccess(selectedToken, requesters);
            await tx.wait();
            showNotification(`${requesters.length} request(s) denied`, 'success');
            setSelectedRequests(new Set());
            loadAccessData();
        } catch (error) {
            console.error('Error batch denying:', error);
            showNotification('Failed to batch deny', 'error');
        }
    };

    const toggleRequestSelection = (address) => {
        setSelectedRequests(prev => {
            const next = new Set(prev);
            next.has(address) ? next.delete(address) : next.add(address);
            return next;
        });
    };

    const openBatchApproveModal = () => {
        setSelectedCredTypes({0: true, 1: true, 2: true, 3: true, 4: true});
        setSelectedSocialSections({0: true, 1: true, 2: true});
        setShowBatchApproveModal(true);
    };

    const handleDenyAccess = async (requester) => {
        try {
            const tx = await contracts.soulbound.denyAccess(selectedToken, requester);
            showNotification('Denying access...', 'info');
            await tx.wait();
            showNotification('Access denied', 'success');
            loadAccessData();
        } catch (error) {
            console.error('Error denying access:', error);
            showNotification('Failed to deny access', 'error');
        }
    };

    const handleRevokeAccess = async (requester) => {
        try {
            const reason = "Access revoked by token owner";
            showNotification('Revoking access...', 'info');
            const tx = await contracts.soulbound.revokeAccess(selectedToken, requester, reason);
            await tx.wait();
            showNotification('Access revoked!', 'success');
            loadAccessData();
        } catch (error) {
            console.error('Error revoking access:', error);
            showNotification('Failed to revoke access', 'error');
        }
    };

    const permCheckboxSection = (title, items, state, setter) => (
        <div style={{ marginBottom: '20px' }}>
            <h4 style={{ color: 'var(--beige)', marginBottom: '12px' }}>{title}</h4>
            {items.map(({ bit, icon, label }) => (
                <label key={bit} style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px', cursor: 'pointer' }}>
                    <input type="checkbox" checked={state[bit]} onChange={(e) => setter(prev => ({ ...prev, [bit]: e.target.checked }))} />
                    <span>{icon} {label}</span>
                </label>
            ))}
        </div>
    );

    if (!selectedToken) {
        return (
            <Card>
                <div className="empty-state">
                    <div className="empty-icon">🔐</div>
                    <h3>Select an Identity Token</h3>
                    <p>Choose a token from the Identity tab to manage access</p>
                </div>
            </Card>
        );
    }

    const credItems = [
        { bit: 0, icon: '🎓', label: 'Degrees' }, { bit: 1, icon: '📜', label: 'Certifications' },
        { bit: 2, icon: '💼', label: 'Work Experience' }, { bit: 3, icon: '🆔', label: 'Identity Proofs' }, { bit: 4, icon: '⚡', label: 'Skills' }
    ];
    const socialItems = [
        { bit: 0, icon: '⭐', label: 'Reviews & Reputation' }, { bit: 1, icon: '🚀', label: 'Projects' }, { bit: 2, icon: '👍', label: 'Endorsements' }
    ];

    return (
        <div className="access-tab">
            <div className="tab-header">
                <div>
                    <h2>Access Control</h2>
                    <p className="tab-description">Manage who can view your identity and credentials</p>
                </div>
                <Button onClick={() => setShowRequestModal(true)}>Request Access to Token</Button>
            </div>

            <div className="access-sections">
                <Card>
                    <div className="section-header">
                        <h3>Pending Access Requests</h3>
                        <span className="badge">{pendingRequests.length}</span>
                    </div>
                    {loading ? <LoadingSpinner /> : pendingRequests.length === 0 ? (
                        <div className="empty-message"><p>No pending access requests</p></div>
                    ) : (
                        <>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px', flexWrap: 'wrap' }}>
                                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px', color: 'var(--gray-light)' }}>
                                    <input type="checkbox" checked={selectedRequests.size === pendingRequests.length && pendingRequests.length > 0} onChange={(e) => { if (e.target.checked) { setSelectedRequests(new Set(pendingRequests.map(r => r.address || r))); } else { setSelectedRequests(new Set()); } }} />
                                    Select all
                                </label>
                                {selectedRequests.size > 0 && (
                                    <>
                                        <span style={{ fontSize: '13px', color: 'var(--gray)' }}>{selectedRequests.size} selected</span>
                                        <Button onClick={openBatchApproveModal} style={{ padding: '6px 14px', fontSize: '12px' }}>✓ Approve Selected</Button>
                                        <Button variant="danger" onClick={handleBatchDeny} style={{ padding: '6px 14px', fontSize: '12px' }}>✕ Deny Selected</Button>
                                    </>
                                )}
                            </div>
                            <div className="requests-list">
                                {pendingRequests.map((requester, idx) => {
                                    const addr = requester.address || requester;
                                    const statusInfo = getAccessStatusLabel(requester.status || 1);
                                    return (
                                        <div key={idx} className="request-item">
                                            <input type="checkbox" checked={selectedRequests.has(addr)} onChange={() => toggleRequestSelection(addr)} style={{ flexShrink: 0 }} />
                                            <div className="requester-info" style={{ flex: 1 }}>
                                                <div className="requester-avatar">👤</div>
                                                <div style={{ flex: 1 }}>
                                                    <div className="requester-address">{shortenAddress(addr)}</div>
                                                    <div className="requester-label">Wallet Address</div>
                                                    <div style={{ marginTop: '8px', display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', background: 'rgba(245, 158, 11, 0.1)', borderRadius: '12px', fontSize: '0.85rem', fontWeight: '600', color: statusInfo.color }}>
                                                        {statusInfo.icon} {statusInfo.label}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="request-actions">
                                                <Button onClick={() => openApproveModal(addr)} style={{ padding: '8px 16px', fontSize: '13px' }}>Approve</Button>
                                                <Button variant="danger" onClick={() => handleDenyAccess(addr)} style={{ padding: '8px 16px', fontSize: '13px' }}>Deny</Button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </>
                    )}
                </Card>

                <Card>
                    <div className="section-header">
                        <h3>Granted Access</h3>
                        <span className="badge">{grantedAccess.length}</span>
                    </div>
                    {loading ? <LoadingSpinner /> : grantedAccess.length === 0 ? (
                        <div className="empty-message"><p>You haven't granted access to anyone yet</p></div>
                    ) : (
                        <div className="requests-list">
                            {grantedAccess.map((item, idx) => (
                                <div key={idx} className="request-item">
                                    <div className="requester-info">
                                        <div className="requester-avatar">✓</div>
                                        <div style={{ flex: 1 }}>
                                            <div className="requester-address">{shortenAddress(item.address)}</div>
                                            <div className="requester-label" style={{ marginTop: '8px' }}>📅 Granted: {formatDate(item.expiresAt - (30 * 24 * 60 * 60))}</div>
                                            <div style={{ marginTop: '8px', padding: '6px 12px', background: 'rgba(6, 182, 212, 0.1)', borderRadius: '6px', display: 'inline-block' }}>
                                                <span style={{ fontSize: '0.9rem', fontWeight: '600', color: item.expiresAt > Math.floor(Date.now() / 1000) ? 'var(--success)' : 'var(--error)' }}>
                                                    {getExpiryCountdown(item.expiresAt)}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="request-actions">
                                        <Button variant="danger" onClick={() => handleRevokeAccess(item.address)} style={{ padding: '8px 16px', fontSize: '13px' }}>Revoke Access</Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </Card>

                <Card>
                    <div className="section-header">
                        <h3>Tokens I Can Access</h3>
                        <span className="badge">{tokensICanAccess.length}</span>
                    </div>
                    {tokensICanAccess.length === 0 ? (
                        <div className="empty-message"><p>No access granted yet. Request access to view other identities.</p></div>
                    ) : (
                        <div className="requests-list">
                            {tokensICanAccess.map((item, idx) => (
                                <div key={idx} className="request-item">
                                    <div className="requester-info">
                                        <div className="requester-avatar">🪪</div>
                                        <div>
                                            <div className="requester-address">Token #{item.tokenId}</div>
                                            <div className="requester-label">Owner: {shortenAddress(item.owner)}</div>
                                            <div className="requester-label" style={{ color: 'var(--teal-light)', marginTop: '4px' }}>
                                                {item.expiresAt > 0 && item.expiresAt < Date.now() / 1000 ? '⚠️ Access Expired' : `✓ Access until ${formatDate(item.expiresAt)}`}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="request-actions">
                                        <Button disabled={loadingDetails} onClick={async () => {
                                            try {
                                                setLoadingDetails(true);
                                                showNotification('Loading identity details...', 'info');
                                                let ipfsMetadata = null;
                                                if (item.cid && item.cid !== 'N/A') {
                                                    try { const res = await fetch(`${CONFIG.IPFS_GATEWAY}${item.cid}`); if (res.ok) ipfsMetadata = await res.json(); } catch {}
                                                }
                                                const credentials = {};
                                                for (let type = 0; type <= 4; type++) {
                                                    try {
                                                        const creds = await contracts.credentials.getCredentialsByType(item.tokenId, type);
                                                        credentials[type] = creds.map(c => ({ id: c.credentialId.toString(), issuer: c.issuer, issueDate: c.issueDate.toNumber(), expiryDate: c.expiryDate.toNumber(), status: c.status, category: c.category, verified: c.verified }));
                                                    } catch { credentials[type] = []; }
                                                }
                                                let reputation = null;
                                                try {
                                                    const rep = await contracts.social.getReputationSummary(item.tokenId);
                                                    reputation = { averageScore: rep.averageScore.toNumber(), totalReviews: rep.totalReviews.toNumber(), verifiedReviews: rep.verifiedReviews.toNumber() };
                                                } catch {}
                                                setViewingToken({ ...item, ipfsMetadata, credentials, reputation });
                                                setShowViewModal(true);
                                            } catch { showNotification('Failed to load token details', 'error'); }
                                            finally { setLoadingDetails(false); }
                                        }} style={{ padding: '8px 16px', fontSize: '13px' }}>
                                            {loadingDetails ? 'Loading...' : '👁️ View Details'}
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </Card>

                <Card>
                    <div className="section-header"><h3>Privacy Settings</h3></div>
                    <div className="privacy-info">
                        {[
                            { icon: '🔒', title: 'Default Privacy', text: 'Your identity and credentials are private by default. Only you can view them unless you grant access.' },
                            { icon: '⏱️', title: 'Time-Limited Access', text: "When you approve access, it's granted for 30 days by default. You can revoke access at any time." },
                            { icon: '🛡️', title: 'Request Tracking', text: 'All access requests are tracked on-chain for transparency and security.' },
                            { icon: '🎯', title: 'Selective Disclosure', text: 'When approving access, you choose exactly which credential types and social sections the requester can see.' }
                        ].map(({ icon, title, text }) => (
                            <div key={title} className="info-item">
                                <div className="info-icon">{icon}</div>
                                <div><h4>{title}</h4><p>{text}</p></div>
                            </div>
                        ))}
                    </div>
                </Card>
            </div>

            <Modal isOpen={showApproveModal} onClose={() => setShowApproveModal(false)} title="Approve Access Request">
                <div className="request-form">
                    <p style={{ color: 'var(--gray-light)', marginBottom: '20px' }}>
                        Approving access for <code style={{ color: 'var(--teal-light)' }}>{approvingRequester && shortenAddress(approvingRequester)}</code> for <strong>30 days</strong>. Choose what they can see:
                    </p>
                    {permCheckboxSection('📋 Credentials', credItems, selectedCredTypes, setSelectedCredTypes)}
                    {permCheckboxSection('🌐 Social', socialItems, selectedSocialSections, setSelectedSocialSections)}
                    <div className="modal-actions">
                        <Button variant="secondary" onClick={() => setShowApproveModal(false)}>Cancel</Button>
                        <Button onClick={handleApproveAccess}>Approve Access</Button>
                    </div>
                </div>
            </Modal>

            <Modal isOpen={showBatchApproveModal} onClose={() => setShowBatchApproveModal(false)} title={`Batch Approve ${selectedRequests.size} Request(s)`}>
                <div className="request-form">
                    <p style={{ color: 'var(--gray-light)', marginBottom: '20px' }}>
                        Approving <strong style={{ color: 'var(--teal-light)' }}>{selectedRequests.size}</strong> request(s) for <strong>30 days</strong>. Choose what they can see:
                    </p>
                    {permCheckboxSection('📋 Credentials', credItems, selectedCredTypes, setSelectedCredTypes)}
                    {permCheckboxSection('🌐 Social', socialItems, selectedSocialSections, setSelectedSocialSections)}
                    <div style={{ background: 'rgba(14,116,144,0.08)', border: '1px solid rgba(14,116,144,0.3)', borderRadius: '8px', padding: '12px', fontSize: '13px', color: 'var(--gray-light)', marginBottom: '4px' }}>
                        This sends up to 3 transactions: one to approve identity access, one for credential permissions, one for social permissions.
                    </div>
                    <div className="modal-actions">
                        <Button variant="secondary" onClick={() => setShowBatchApproveModal(false)}>Cancel</Button>
                        <Button onClick={handleBatchApprove}>Approve All Selected</Button>
                    </div>
                </div>
            </Modal>

            <Modal isOpen={showRequestModal} onClose={() => setShowRequestModal(false)} title="Request Access">
                <div className="request-form">
                    <Input label="Token ID" value={requestTokenId} onChange={setRequestTokenId} placeholder="Enter token ID" type="number" required />
                    <div className="info-box"><strong>Note:</strong> You're requesting access to view another user's identity and credentials. The owner will need to approve your request.</div>
                    <div className="modal-actions">
                        <Button variant="secondary" onClick={() => setShowRequestModal(false)}>Cancel</Button>
                        <Button onClick={handleRequestAccess} disabled={!requestTokenId}>Send Request</Button>
                    </div>
                </div>
            </Modal>

            <Modal isOpen={showViewModal} onClose={() => setShowViewModal(false)} title={viewingToken ? `Token #${viewingToken.tokenId} — Identity` : 'Identity Details'}>
                {viewingToken && (
                    <div className="token-view-details">
                        <div style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.3)', borderRadius: '8px', padding: '10px 16px', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.85rem', color: '#10b981' }}>
                            <span>🔓</span>
                            <span><strong>Read access granted</strong>{viewingToken.expiresAt > 0 && ` · Expires ${formatDate(viewingToken.expiresAt)}`}{' · '}<span style={{ color: 'var(--gray)' }}>Owner: </span><code style={{ color: 'var(--teal-light)', fontSize: '0.82rem' }}>{viewingToken.owner}</code></span>
                        </div>
                        <div className="detail-section">
                            <h4>Profile</h4>
                            <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
                                {viewingToken.ipfsMetadata?.profileImage ? (
                                    <img src={viewingToken.ipfsMetadata.profileImage} alt="Profile" style={{ width: '64px', height: '64px', borderRadius: '12px', objectFit: 'cover', flexShrink: 0 }} />
                                ) : (
                                    <div style={{ width: '64px', height: '64px', borderRadius: '12px', flexShrink: 0, background: 'rgba(14,116,144,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28px' }}>👤</div>
                                )}
                                <div>
                                    <div style={{ fontSize: '1.15rem', fontWeight: '700', color: 'var(--beige)', marginBottom: '6px' }}>{viewingToken.ipfsMetadata?.name || `Token #${viewingToken.tokenId}`}</div>
                                    {viewingToken.ipfsMetadata?.bio && <div style={{ color: 'var(--gray-light)', fontSize: '0.9rem', lineHeight: '1.5' }}>{viewingToken.ipfsMetadata.bio}</div>}
                                    {!viewingToken.ipfsMetadata && <div style={{ color: 'var(--gray)', fontSize: '0.85rem' }}>No profile metadata found on IPFS</div>}
                                </div>
                            </div>
                        </div>
                        {viewingToken.credentials && (
                            <div className="detail-section">
                                <h4>Credentials</h4>
                                {[{ type: 0, icon: '🎓', label: 'Degrees' }, { type: 1, icon: '📜', label: 'Certifications' }, { type: 2, icon: '💼', label: 'Work Experience' }, { type: 3, icon: '🆔', label: 'Identity Proofs' }, { type: 4, icon: '⚡', label: 'Skills' }].map(({ type, icon, label }) => {
                                    const creds = viewingToken.credentials[type] || [];
                                    return (
                                        <div key={type} style={{ marginBottom: '16px' }}>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px', fontSize: '0.95rem', color: 'var(--beige)', fontWeight: '600' }}>
                                                <span>{icon}</span><span>{label}</span>
                                                <span style={{ background: creds.length > 0 ? 'rgba(14,116,144,0.2)' : 'rgba(156,163,175,0.1)', color: creds.length > 0 ? 'var(--teal-light)' : 'var(--gray)', borderRadius: '10px', padding: '1px 8px', fontSize: '0.78rem', fontWeight: '700' }}>{creds.length}</span>
                                            </div>
                                            {creds.length === 0 ? (
                                                <div style={{ color: 'var(--gray)', fontSize: '0.82rem', paddingLeft: '8px' }}>No {label.toLowerCase()} on record</div>
                                            ) : (
                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '4px' }}>
                                                    {creds.map((cred, i) => (
                                                        <div key={i} style={{ background: 'rgba(26,35,50,0.6)', borderRadius: '8px', padding: '12px', borderLeft: `3px solid ${cred.status === 0 ? 'var(--teal)' : cred.status === 1 ? 'var(--error, #ef4444)' : 'var(--gray)'}` }}>
                                                            <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '8px', flexWrap: 'wrap' }}>
                                                                {cred.verified ? <span style={{ background: 'rgba(16,185,129,0.15)', color: '#10b981', borderRadius: '4px', padding: '2px 8px', fontSize: '0.72rem', fontWeight: '700' }}>✓ Verified</span> : <span style={{ background: 'rgba(245,158,11,0.12)', color: '#f59e0b', borderRadius: '4px', padding: '2px 8px', fontSize: '0.72rem', fontWeight: '600' }}>Self-reported</span>}
                                                                <span style={{ background: cred.status === 0 ? 'rgba(14,116,144,0.15)' : cred.status === 1 ? 'rgba(239,68,68,0.15)' : 'rgba(156,163,175,0.15)', color: cred.status === 0 ? 'var(--teal-light)' : cred.status === 1 ? 'var(--error, #ef4444)' : 'var(--gray)', borderRadius: '4px', padding: '2px 8px', fontSize: '0.72rem' }}>{cred.status === 0 ? 'Active' : cred.status === 1 ? 'Revoked' : 'Expired'}</span>
                                                            </div>
                                                            <div style={{ fontSize: '0.82rem', color: 'var(--gray-light)' }}>Issuer: <code style={{ color: 'var(--teal-light)', fontSize: '0.8rem' }}>{shortenAddress(cred.issuer)}</code></div>
                                                            <div style={{ fontSize: '0.8rem', color: 'var(--gray)', marginTop: '4px', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                                                                <span>Issued: {cred.issueDate > 0 ? formatDate(cred.issueDate) : '—'}</span>
                                                                <span>Expires: {cred.expiryDate > 0 ? formatDate(cred.expiryDate) : 'No expiry'}</span>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                        {viewingToken.reputation !== null && viewingToken.reputation !== undefined && (
                            <div className="detail-section" style={{ paddingBottom: 0, borderBottom: 'none' }}>
                                <h4>Reputation</h4>
                                <div style={{ background: 'rgba(26,35,50,0.6)', borderRadius: '10px', padding: '16px', display: 'flex', gap: '0', alignItems: 'center' }}>
                                    <div style={{ textAlign: 'center', minWidth: '90px' }}>
                                        <div style={{ fontSize: '1.8rem', fontWeight: '800', color: 'var(--teal-light)', lineHeight: 1 }}>{viewingToken.reputation.totalReviews > 0 ? `${viewingToken.reputation.averageScore}` : '—'}</div>
                                        {viewingToken.reputation.totalReviews > 0 && <div style={{ fontSize: '0.72rem', color: 'var(--gray)', marginTop: '2px' }}>out of 100</div>}
                                        <div style={{ fontSize: '0.75rem', color: 'var(--gray)', marginTop: '4px' }}>Score</div>
                                    </div>
                                    <div style={{ borderLeft: '1px solid rgba(14,116,144,0.2)', paddingLeft: '20px', marginLeft: '8px' }}>
                                        {viewingToken.reputation.totalReviews === 0 ? (
                                            <div style={{ color: 'var(--gray)', fontSize: '0.88rem' }}>No reviews yet</div>
                                        ) : (
                                            <>
                                                <div style={{ color: 'var(--beige)', fontSize: '0.9rem', marginBottom: '4px' }}>{viewingToken.reputation.totalReviews} review{viewingToken.reputation.totalReviews !== 1 ? 's' : ''}</div>
                                                <div style={{ color: '#10b981', fontSize: '0.85rem' }}>✓ {viewingToken.reputation.verifiedReviews} verified</div>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </Modal>

            <style>{`
                .access-tab { animation: fadeIn 0.5s ease-out; }
                .tab-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; }
                .tab-header h2 { font-size: 32px; color: var(--teal-light); margin-bottom: 8px; }
                .tab-description { color: var(--gray-light); font-size: 14px; }
                .access-sections { display: flex; flex-direction: column; gap: 20px; }
                .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid rgba(14, 116, 144, 0.3); }
                .section-header h3 { font-size: 20px; color: var(--beige); }
                .badge { background: var(--teal); color: white; padding: 4px 12px; border-radius: 12px; font-size: 13px; font-weight: 600; }
                .empty-message { text-align: center; padding: 40px 20px; color: var(--gray-light); }
                .requests-list { display: flex; flex-direction: column; gap: 12px; }
                .request-item { background: rgba(26, 35, 50, 0.5); border-radius: 8px; padding: 16px; display: flex; justify-content: space-between; align-items: center; gap: 16px; }
                .requester-info { display: flex; align-items: center; gap: 12px; }
                .requester-avatar { width: 40px; height: 40px; background: rgba(14, 116, 144, 0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; }
                .requester-address { font-family: monospace; color: var(--teal-light); font-size: 14px; }
                .requester-label { font-size: 12px; color: var(--gray); margin-top: 2px; }
                .request-actions { display: flex; gap: 8px; }
                .privacy-info { display: flex; flex-direction: column; gap: 20px; }
                .info-item { display: flex; gap: 16px; align-items: flex-start; }
                .info-icon { font-size: 32px; flex-shrink: 0; }
                .info-item h4 { font-size: 16px; color: var(--beige); margin-bottom: 8px; }
                .info-item p { font-size: 14px; color: var(--gray-light); line-height: 1.6; }
                .request-form { display: flex; flex-direction: column; gap: 20px; }
                .info-box { background: rgba(56, 189, 248, 0.1); border: 1px solid var(--sky); border-radius: 8px; padding: 16px; color: var(--beige); font-size: 13px; line-height: 1.5; }
                .modal-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px; }
                .empty-state { text-align: center; padding: 60px 20px; }
                .empty-icon { font-size: 64px; margin-bottom: 20px; }
                .empty-state h3 { font-size: 24px; color: var(--beige); margin-bottom: 12px; }
                .empty-state p { color: var(--gray-light); font-size: 16px; }
                .detail-section { padding: 16px 0; border-bottom: 1px solid rgba(14,116,144,0.15); }
                .detail-section h4 { color: var(--teal-light); font-size: 14px; font-weight: 600; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.05em; }
                @media (max-width: 768px) {
                    .tab-header { flex-direction: column; gap: 16px; }
                    .request-item { flex-direction: column; align-items: flex-start; }
                    .request-actions { width: 100%; }
                    .request-actions button { flex: 1; }
                }
            `}</style>
        </div>
    );
}
